These songs were demixed by FroggestSpirit for use in pokecrystal disassemblies.
Please credit if used, do not claim as your own.
Included are 2 GBS files, one for Pokemon Platinum tracks, and one for the other remixes.
Songs are up to date as of 12/27/2016